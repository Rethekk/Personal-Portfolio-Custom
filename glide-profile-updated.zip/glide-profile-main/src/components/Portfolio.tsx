import { useState, useEffect } from "react";
import Navigation from "./Navigation";
import HeroSection from "./sections/HeroSection";
import AboutSection from "./sections/AboutSection";
import SkillsSection from "./sections/SkillsSection";
import ExperienceSection from "./sections/ExperienceSection";
import ProjectsSection from "./sections/ProjectsSection";
import EducationSection from "./sections/EducationSection";
import ContactSection from "./sections/ContactSection";

const Portfolio = () => {
  const [activeSection, setActiveSection] = useState("home");

  const sections = {
    home: <HeroSection onNavigate={setActiveSection} />,
    about: <AboutSection />,
    skills: <SkillsSection />,
    experience: <ExperienceSection />,
    projects: <ProjectsSection />,
    education: <EducationSection />,
    contact: <ContactSection />
  };

  // Handle scroll-based section detection
  useEffect(() => {
    const handleScroll = () => {
      const sections = ["home", "about", "skills", "experience", "projects", "education", "contact"];
      const current = sections.find(section => {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top <= 100 && rect.bottom >= 100;
        }
        return false;
      });
      if (current && current !== activeSection) {
        setActiveSection(current);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [activeSection]);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
    setActiveSection(sectionId);
  };

  return (
    <div className="relative">
      <Navigation 
        activeSection={activeSection} 
        onSectionChange={scrollToSection} 
      />
      
      <div className="overflow-x-hidden">
        {Object.entries(sections).map(([key, component]) => (
          <div key={key} id={key} className="relative">
            {component}
          </div>
        ))}
      </div>

      {/* Floating particles for extra visual appeal */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-1/4 left-10 w-2 h-2 bg-primary/30 rounded-full animate-float"></div>
        <div className="absolute top-1/2 right-20 w-1 h-1 bg-secondary/40 rounded-full animate-float" style={{ animationDelay: "1s" }}></div>
        <div className="absolute bottom-1/4 left-1/3 w-1.5 h-1.5 bg-accent/30 rounded-full animate-float" style={{ animationDelay: "2s" }}></div>
        <div className="absolute top-3/4 right-1/3 w-1 h-1 bg-primary/20 rounded-full animate-float" style={{ animationDelay: "3s" }}></div>
      </div>
    </div>
  );
};

export default Portfolio;