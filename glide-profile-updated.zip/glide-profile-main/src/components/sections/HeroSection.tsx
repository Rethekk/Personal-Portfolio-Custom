import { Button } from "@/components/ui/button";
import { ArrowDown, Github, Linkedin, Mail } from "lucide-react";

interface HeroSectionProps {
  onNavigate: (section: string) => void;
}

const HeroSection = ({ onNavigate }: HeroSectionProps) => {
  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-3xl animate-float" style={{ animationDelay: "1s" }}></div>
        <div className="absolute top-1/2 left-1/2 w-48 h-48 bg-accent/10 rounded-full blur-3xl animate-float" style={{ animationDelay: "2s" }}></div>
      </div>

      <div className="text-center z-10 max-w-4xl mx-auto px-6">
        {/* Main heading with cyber effect */}
        <div className="mb-8 animate-fade-in">
          <h1 className="text-6xl md:text-8xl font-bold mb-4 neon-text bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            START
          </h1>
          <div className="code-block p-4 rounded-lg mb-6 animate-slide-in-left" style={{ animationDelay: "0.2s" }}>
            <p className="text-lg md:text-xl text-muted-foreground font-mono">
              <span className="text-accent">const</span>{" "}
              <span className="text-primary">developer</span> = {"{"}
            </p>
            <p className="text-lg md:text-xl text-muted-foreground font-mono ml-4">
              <span className="text-secondary">name</span>: <span className="text-accent">"Rethek Kumar"</span>,
            </p>
            <p className="text-lg md:text-xl text-muted-foreground font-mono ml-4">
              <span className="text-secondary">role</span>: <span className="text-accent">"Software Developer"</span>,
            </p>
            <p className="text-lg md:text-xl text-muted-foreground font-mono ml-4">
              <span className="text-secondary">passion</span>: <span className="text-accent">"Creating Amazing Experiences"</span>
            </p>
            <p className="text-lg md:text-xl text-muted-foreground font-mono ml-4">
              <span className="text-secondary">Location</span>: <span className="text-accent">"Open to Relocating Anywhere Inside Canada"</span>
            </p>
            <p className="text-lg md:text-xl text-muted-foreground font-mono">{"}"}</p>
          </div>
        </div>

        {/* Description */}
        <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto animate-slide-in-right" style={{ animationDelay: "0.4s" }}>
          Fresh Applied Computing graduate passionate about building innovative applications. 
          Ready to contribute to cutting-edge projects and grow with a dynamic team.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col md:flex-row gap-4 justify-center mb-12 animate-fade-in" style={{ animationDelay: "0.6s" }}>
          <Button 
            size="lg" 
            className="cyber-glow bg-primary hover:bg-primary/90 text-primary-foreground text-lg px-8 py-6"
            onClick={() => onNavigate("projects")}
          >
            View My Work
          </Button>
          <Button 
            size="lg" 
            variant="outline" 
            className="cyber-glow border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground text-lg px-8 py-6"
            onClick={() => onNavigate("contact")}
          >
            Get In Touch
          </Button>
        </div>

     {/* Social Links */}
<div className="flex justify-center space-x-6 mb-12 animate-fade-in" style={{ animationDelay: "0.8s" }}>
  <a href="https://github.com/rethekk" target="_blank" rel="noopener noreferrer">
    <Button variant="ghost" size="icon" className="cyber-glow hover:text-primary">
      <Github size={24} />
    </Button>
  </a>
  <a href="https://www.linkedin.com/in/rethek-kumar-rk0/" target="_blank" rel="noopener noreferrer">
    <Button variant="ghost" size="icon" className="cyber-glow hover:text-primary">
      <Linkedin size={24} />
    </Button>
  </a>
  <a href="mailto:rethekkumar00@gmail.com">
    <Button variant="ghost" size="icon" className="cyber-glow hover:text-primary">
      <Mail size={24} />
    </Button>
  </a>
</div>

        {/* Scroll indicator */}
        <div className="animate-bounce">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => onNavigate("about")}
            className="text-muted-foreground hover:text-primary"
          >
            <ArrowDown size={24} />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;