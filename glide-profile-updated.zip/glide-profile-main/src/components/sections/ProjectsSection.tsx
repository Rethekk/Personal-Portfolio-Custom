import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Github } from "lucide-react";

const ProjectsSection = () => {
  const projects = [
    {
      title: "E-Commerce Platform",
      description: "Full-stack e-commerce solution with React, Node.js, and PostgreSQL. Features include user authentication, payment processing, and admin dashboard.",
      tech: ["React", "Node.js", "PostgreSQL", "Stripe", "JWT"],
      demoUrl: "#",
      githubUrl: "#",
      status: "Completed"
    },
    {
      title: "Task Management App",
      description: "Collaborative project management tool with real-time updates, drag-and-drop functionality, and team collaboration features.",
      tech: ["Vue.js", "Express.js", "Socket.io", "MongoDB"],
      demoUrl: "#",
      githubUrl: "#",
      status: "In Progress"
    },
    {
      title: "Weather Dashboard",
      description: "Interactive weather application with location-based forecasts, historical data visualization, and responsive design.",
      tech: ["React", "TypeScript", "Chart.js", "OpenWeather API"],
      demoUrl: "#",
      githubUrl: "#",
      status: "Completed"
    },
    {
      title: "Portfolio Website",
      description: "Personal portfolio website showcasing projects and skills with modern animations and responsive design.",
      tech: ["React", "Tailwind CSS", "Framer Motion", "Vercel"],
      demoUrl: "#",
      githubUrl: "#",
      status: "Completed"
    }
  ];

  return (
    <section className="min-h-screen py-20 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in">
          <div className="code-block p-4 rounded-lg inline-block mb-6">
            <span className="text-primary font-mono">projects</span>
            <span className="text-muted-foreground font-mono">.filter(</span>
            <span className="text-accent font-mono">impressive</span>
            <span className="text-muted-foreground font-mono">)</span>
          </div>
          <h2 className="text-4xl md:text-6xl font-bold neon-text">
            Featured Projects
          </h2>
          <p className="text-xl text-muted-foreground mt-4 max-w-2xl mx-auto">
            Here are some of my recent projects that showcase my technical skills and creativity
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <Card 
              key={index}
              className="cyber-glow bg-card/30 backdrop-blur-sm border-border hover:bg-card/50 transition-all duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <CardHeader>
                <div className="flex justify-between items-start mb-2">
                  <CardTitle className="text-xl text-foreground">
                    {project.title}
                  </CardTitle>
                  <Badge 
                    variant="outline" 
                    className={`${
                      project.status === "Completed" 
                        ? "border-primary text-primary" 
                        : "border-secondary text-secondary"
                    }`}
                  >
                    {project.status}
                  </Badge>
                </div>
                <p className="text-muted-foreground leading-relaxed">
                  {project.description}
                </p>
              </CardHeader>
              
              <CardContent>
                {/* Tech Stack */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-foreground mb-3">Tech Stack:</h4>
                  <div className="flex flex-wrap gap-2">
                    {project.tech.map((tech, techIndex) => (
                      <Badge 
                        key={techIndex}
                        variant="outline"
                        className="border-accent/50 text-accent hover:bg-accent/20"
                      >
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                {/* <div className="flex gap-3">
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="cyber-glow border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                  >
                    <ExternalLink size={16} className="mr-2" />
                    Live Demo
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="cyber-glow border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground"
                  >
                    <Github size={16} className="mr-2" />
                    Code
                  </Button>
                </div> */}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action
        <div className="text-center mt-16 animate-fade-in" style={{ animationDelay: "0.8s" }}>
          <Card className="cyber-glow bg-card/20 backdrop-blur-sm border-border">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-foreground mb-4">
                Want to see more?
              </h3>
              <p className="text-muted-foreground mb-6">
                Check out my GitHub for more projects and contributions
              </p>
              <Button className="cyber-glow bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90">
                <Github size={20} className="mr-2" />
                Visit GitHub Profile
              </Button>
            </CardContent>
          </Card>
        </div> */}
      </div>
    </section>
  );
};

export default ProjectsSection;