import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Code, Coffee, Lightbulb, Target } from "lucide-react";

const AboutSection = () => {
  const highlights = [
    {
      icon: <Code className="w-8 h-8 text-primary" />,
      title: "Problem Solver",
      description: "Love tackling complex challenges with clean, efficient code"
    },
    {
      icon: <Lightbulb className="w-8 h-8 text-secondary" />,
      title: "Innovation Driven",
      description: "Always exploring new technologies and best practices"
    },
    {
      icon: <Target className="w-8 h-8 text-accent" />,
      title: "Goal Oriented",
      description: "Focused on delivering results that make a real impact"
    },
    {
      icon: <Coffee className="w-8 h-8 text-primary" />,
      title: "Team Player",
      description: "Collaborate effectively and share knowledge with others"
    }
  ];

  return (
    <section className="min-h-screen py-20 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in">
          <div className="code-block p-4 rounded-lg inline-block mb-6">
            <span className="text-accent font-mono">&lt;</span>
            <span className="text-primary font-mono">h1</span>
            <span className="text-accent font-mono">&gt;</span>
            <span className="text-foreground font-mono">About Me</span>
            <span className="text-accent font-mono">&lt;/</span>
            <span className="text-primary font-mono">h1</span>
            <span className="text-accent font-mono">&gt;</span>
          </div>
          <h2 className="text-4xl md:text-6xl font-bold neon-text mb-4">
            Hi, I'm Rethek.
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left side - Profile info */}
          <div className="animate-slide-in-left">
            <Card className="cyber-glow bg-card/50 backdrop-blur-sm border-border">
              <CardContent className="p-8">
                <div className="code-block p-6 rounded-lg mb-6">
                  <p className="font-mono text-sm mb-2">
                    <span className="text-accent">class</span>{" "}
                    <span className="text-primary">Developer</span> {"{"}
                  </p>
                  <p className="font-mono text-sm ml-4 mb-1">
                    <span className="text-secondary">constructor</span>() {"{"}
                  </p>
                  <p className="font-mono text-sm ml-8 mb-1">
                    <span className="text-muted-foreground">this.</span>
                    <span className="text-accent">passion</span> = 
                    <span className="text-primary"> "Analyst"</span>;
                  </p>
                  <p className="font-mono text-sm ml-8 mb-1">
                    <span className="text-muted-foreground">this.</span>
                    <span className="text-accent">focus</span> = 
                    <span className="text-primary"> "Innovation"</span>;
                  </p>
                  <p className="font-mono text-sm ml-4 mb-2">{"}"}</p>
                  <p className="font-mono text-sm">{"}"}</p>
                </div>
                
                <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                Recent Master’s graduate with 1+ years of experience in business analysis, quality assurance, and technical support. Proven
track record of reducing support incidents by 45% through systematic process improvement and stakeholder collaboration.
Expertise in requirements gathering, JIRA project management, and cross-functional team coordination with 95%+ satisfaction
ratings. Strong analytical background in translating business needs into technical solutions while maintaining 99.2% system
uptime.
                </p>
                

                <Button className="cyber-glow bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90">
                  Download Resume
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Right side - Highlights */}
          <div className="space-y-6 animate-slide-in-right">
            {highlights.map((item, index) => (
              <Card 
                key={index} 
                className="cyber-glow bg-card/30 backdrop-blur-sm border-border hover:bg-card/50 transition-all duration-300"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-6 flex items-center space-x-4">
                  <div className="animate-float" style={{ animationDelay: `${index * 0.5}s` }}>
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-foreground mb-2">
                      {item.title}
                    </h3>
                    <p className="text-muted-foreground">
                      {item.description}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;