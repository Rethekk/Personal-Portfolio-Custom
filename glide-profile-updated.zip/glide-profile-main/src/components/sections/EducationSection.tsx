import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, Award, BookOpen, Calendar } from "lucide-react";

const EducationSection = () => {
  const education = [
    {
      degree: "Master of Applied Computing",
      institution: "University of Windsor",
      period: "2023 - 2024",
      gpa: "",
      status: "",
      description: "Comprehensive program covering software development, database management.",
      coursework: [
        "Advanced Software Engineering Topics",
        "Advanced Database Topics",
        "Advanced Systems Programming",
        "Managing Employees",
      ]
    },
    {
      degree: "Bachelor of Science in Computer Science",
      institution: "National University of Computer And Emerging Sciences",
      period: "2018 - 2022",
      gpa: "",
      status: "",
      description: "Comprehensive program covering software development, database management, Artificial Intelligence, and project management.",
      coursework: [
        "Data Structures & Algorithms",
        "Agile Software Project Management",
        "Object Orientied Programming",
        "Requirement Engineering For Software and Systems",
        "Database Systems",
        "Data Science"
      ]
    }
  ];

  const certifications = [
    {
      title: "SQL Advanced",
      issuer: "Hackerrank",
      date: "2024",
      status: "Active"
    },
    {
      title: "Software Engineering Intern",
      issuer: "SQL",
      date: "2024",
      status: "Active"
    }
  ];

  const achievements = [
    {
      title: "Dean's List",
      description: "Achieved Dean's List recognition for Spring 2022 semester",
      icon: <Award className="w-6 h-6 text-accent" />
    },
    {
      title: "Dean's List",
      description: "Achieved Dean's List recognition for Fall 2021 semester",
      icon: <Award className="w-6 h-6 text-primary" />
    }
  ];

  return (
    <section className="min-h-screen py-20 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in">
          <div className="code-block p-4 rounded-lg inline-block mb-6">
            <span className="text-primary font-mono">knowledge</span>
            <span className="text-muted-foreground font-mono">.expand(</span>
            <span className="text-accent font-mono">continuously</span>
            <span className="text-muted-foreground font-mono">)</span>
          </div>
          <h2 className="text-4xl md:text-6xl font-bold neon-text">
            Education & Growth
          </h2>
          <p className="text-xl text-muted-foreground mt-4">
            Academic foundation and continuous learning journey
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Education */}
          <div className="lg:col-span-2">
            {education.map((edu, index) => (
              <Card 
                key={index}
                className="cyber-glow bg-card/30 backdrop-blur-sm border-border mb-8 animate-slide-in-left"
              >
                <CardContent className="p-8">
                  <div className="flex items-start gap-4 mb-6">
                    <div className="p-3 bg-primary/20 rounded-lg">
                      <GraduationCap className="w-8 h-8 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-foreground mb-2">
                        {edu.degree}
                      </h3>
                      <h4 className="text-xl text-primary mb-2">
                        {edu.institution}
                      </h4>
                      <div className="flex items-center gap-4 text-muted-foreground mb-2">
                        <div className="flex items-center">
                          <Calendar size={16} className="mr-1" />
                          {edu.period}
                        </div>
                        {/* <Badge variant="outline" className="border-secondary text-secondary">
                          {edu.status}
                        </Badge> */}
                      </div>
                      {/* <div className="text-lg font-semibold text-accent">
                        GPA: {edu.gpa}
                      </div> */}
                    </div>
                  </div>

                  <p className="text-muted-foreground mb-6 leading-relaxed">
                    {edu.description}
                  </p>

                  <div>
                    <h5 className="text-lg font-semibold text-foreground mb-3 flex items-center">
                      <BookOpen size={20} className="mr-2 text-primary" />
                      Relevant Coursework:
                    </h5>
                    <div className="grid md:grid-cols-2 gap-2">
                      {edu.coursework.map((course, courseIndex) => (
                        <div 
                          key={courseIndex}
                          className="flex items-center text-muted-foreground"
                        >
                          <span className="text-accent mr-2">▸</span>
                          {course}
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Achievements */}
            <Card className="cyber-glow bg-card/30 backdrop-blur-sm border-border animate-slide-in-left" style={{ animationDelay: "0.2s" }}>
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-foreground mb-6">
                  Academic Achievements
                </h3>
                <div className="space-y-4">
                  {achievements.map((achievement, index) => (
                    <div key={index} className="flex items-center gap-4 p-4 bg-card/20 rounded-lg">
                      <div className="animate-float" style={{ animationDelay: `${index * 0.5}s` }}>
                        {achievement.icon}
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground">
                          {achievement.title}
                        </h4>
                        <p className="text-muted-foreground">
                          {achievement.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Certifications Sidebar */}
          <div className="animate-slide-in-right">
            <Card className="cyber-glow bg-card/30 backdrop-blur-sm border-border sticky top-6">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-foreground mb-6">
                  Certifications
                </h3>
                <div className="space-y-4">
                  {certifications.map((cert, index) => (
                    <div 
                      key={index}
                      className="p-4 bg-card/20 rounded-lg border border-border/50"
                    >
                      <h4 className="font-semibold text-foreground mb-2">
                        {cert.title}
                      </h4>
                      <p className="text-sm text-primary mb-1">
                        {cert.issuer}
                      </p>
                      <p className="text-sm text-muted-foreground mb-2">
                        Issued: {cert.date}
                      </p>
                      <div className="flex justify-between items-center">
                        <Badge 
                          variant="outline" 
                          className="border-primary/50 text-primary text-xs"
                        >
                          {cert.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 text-center">
                  <p className="text-sm text-muted-foreground mb-3">
                    Always learning new technologies
                  </p>
                  <div className="flex justify-center">
                    <Badge variant="outline" className="border-accent text-accent">
                      Next: Certified Data Engineer Associate
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EducationSection;