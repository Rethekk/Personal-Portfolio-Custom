import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const SkillsSection = () => {
  const skillCategories = [
    {
      title: "Languages",
      color: "text-primary",
      skills: ["C#", "Python", "C++", "SQL", "NoSQL"]
    },
    {
      title: "Databases & Data Engineering",
      color: "text-secondary",
      skills: ["MongoDB", "Redis", "MS SQL Server", "MySQL","Data Processing", "Data Transformation"]
    },
    {
      title: "Technologies/Frameworks",
      color: "text-accent",
      skills: [".NET", "Redis", "REST APIs", "gRPC","Pandas", "NumPy", "Scikit-learn", "Keras"]
    },
     {
      title: "Software Development",
      color: "text-accent",
      skills: ["Object-Oriented Design", "Agile", "Version Control (Git, TFS)", "Unit Testing","Requirement Engineering"]
    },
     {
      title: "Tools",
      color: "text-accent",
      skills: ["Power BI", "Matplotlib", "Azure DevOps", "JIRA", "Confluence"]
    },
    {
      title: "Soft Skills",
      color: "text-primary",
      skills: ["Problem Solving", "Team Leadership", "Communication", "Project Management", "Agile/Scrum", "Client Relations"]
    }
  ];

  return (
    <section className="min-h-screen py-20 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in">
          <div className="code-block p-4 rounded-lg inline-block mb-6">
            <span className="text-accent font-mono">Skills</span>
            <span className="text-muted-foreground font-mono">.map(skill =&gt; </span>
            <span className="text-primary font-mono">expertise</span>
            <span className="text-muted-foreground font-mono">)</span>
          </div>
          <h2 className="text-4xl md:text-6xl font-bold neon-text">
            Technical Arsenal
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {skillCategories.map((category, categoryIndex) => (
            <Card 
              key={categoryIndex}
              className="cyber-glow bg-card/30 backdrop-blur-sm border-border animate-fade-in"
              style={{ animationDelay: `${categoryIndex * 0.2}s` }}
            >
              <CardContent className="p-8">
                <h3 className={`text-2xl font-bold mb-6 ${category.color} neon-text`}>
                  {category.title}
                </h3>
                <div className="flex flex-wrap gap-3">
                  {category.skills.map((skill, skillIndex) => (
                    <Badge 
                      key={skillIndex}
                      variant="outline"
                      className="cyber-glow border-primary/50 text-foreground hover:bg-primary/20 hover:border-primary transition-all duration-300 animate-slide-in-left"
                      style={{ animationDelay: `${categoryIndex * 0.2 + skillIndex * 0.1}s` }}
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Proficiency Levels */}
        <div className="mt-16 animate-fade-in" style={{ animationDelay: "0.8s" }}>
          <Card className="cyber-glow bg-card/20 backdrop-blur-sm border-border">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-center mb-8 text-secondary neon-text">
                Proficiency Overview
              </h3>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-4xl font-bold text-primary mb-2">80%</div>
                  <div className="text-lg text-muted-foreground">Development</div>
                  <div className="w-full bg-border h-2 rounded-full mt-2">
                    <div className="w-[85%] bg-gradient-to-r from-primary to-secondary h-full rounded-full animate-slide-in-left"></div>
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-secondary mb-2">75%</div>
                  <div className="text-lg text-muted-foreground">Data Analysis</div>
                  <div className="w-full bg-border h-2 rounded-full mt-2">
                    <div className="w-[80%] bg-gradient-to-r from-secondary to-accent h-full rounded-full animate-slide-in-left" style={{ animationDelay: "0.2s" }}></div>
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-accent mb-2">75%</div>
                  <div className="text-lg text-muted-foreground">Business Analysis</div>
                  <div className="w-full bg-border h-2 rounded-full mt-2">
                    <div className="w-[75%] bg-gradient-to-r from-accent to-primary h-full rounded-full animate-slide-in-left" style={{ animationDelay: "0.4s" }}></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;