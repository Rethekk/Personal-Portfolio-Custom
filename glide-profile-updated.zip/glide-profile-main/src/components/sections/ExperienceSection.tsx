import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin } from "lucide-react";

const ExperienceSection = () => {
  const experiences = [
    {
      title: "Software Developer",
      company: "Spursol Pvt Ltd",
      // location: "Karachi, PK",
      period: "September 2022 - August 2023",
      type: "Full-time",
      description: "Developed and optimized enterprise data solutions by automating ETL processes, building interactive dashboards, and improving system performance for mortgage operations. Collaborated with cross-functional teams to deliver data-driven insights and scalable software tools.",
      achievements: [
        "Automated ETL pipelines from SQL Server to MongoDB using .NET, increasing data availability by 20% and eliminating manual data transfer.",
"Built 9 interactive KPI dashboards (D3.js, Power BI) to monitor mortgage performance, improving operational decision-making speed.",
"Reduced dashboard load times by 50% with Redis caching, enhancing user experience.",
"Transformed 90+ data fields into actionable visual insights, enabling cross-functional teams to make faster, evidence-based decisions.",
"Collected feedback from 10+ stakeholders to refine product requirements, reducing rework and improving feature alignment."
      ],
      skills: [" .NET Development"," Data Integration"," Power BI"," D3.js"," Redis Caching"," Requirements Engineering"," Client Relations", " Workflow Optimization"]
    },
    {
      title: "Technical Business Analyst",
      company: "Sibisoft Pvt Ltd",
      // location: "Karachi, PK",
      period: "July 2022 - August 2022",
      type: "Full-time",
      description: "Bridged the gap between technical and business teams by documenting processes, analyzing requirements, and optimizing workflows. Created resources that reduced support demand and enhanced development productivity.",
      achievements: [
"Accelerated feature delivery by 30% through use-case analysis, process diagrams, and Figma wireframes.",
"Reduced support tickets by 25% with comprehensive SRS documentation, user guides, and FAQs.",
"Increased QA efficiency by 50% by designing and executing structured test cases.",
"Improved project planning accuracy by streamlining workflow documentation in Visio and Microsoft Project."
      ],
      skills: ["Requirements Gathering", " Process Documentation", " Figma Wireframing"," Test Case Design", "Team Leadership", "Stakeholder Management"]
    },
    {
      title: "Customer Service & Post Office Clerk",
      company: "Shoppers Drug Mart",
      // location: "San Francisco, CA",
      period: "January 2024 - Present",
      type: "Part-Time",
      description: "Handled 100+ daily customer interactions while maintaining 95%+ satisfaction ratings across multiple channels.Troubleshot basic technical issues and maintain operational documentation for process continuity",
      achievements: [
        "Recognized as Employee of the Month twice",
        "Successfully Led donation collection efforts for the Canada Post Community Foundation",
      ],
      skills: ["Problem-Solving", "Attention to Detail", "Communication & Team Collaboration", "Process Optimization"]
    }
  ];

  return (
    <section className="min-h-screen py-20 px-6">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in">
          <div className="code-block p-4 rounded-lg inline-block mb-6">
            <span className="text-primary font-mono">experience</span>
            <span className="text-muted-foreground font-mono">.sort(</span>
            <span className="text-accent font-mono">byRelevance</span>
            <span className="text-muted-foreground font-mono">)</span>
          </div>
          <h2 className="text-4xl md:text-6xl font-bold neon-text">
            Professional Journey
          </h2>
          <p className="text-xl text-muted-foreground mt-4">
            Building expertise through diverse experiences in consulting and development
          </p>
        </div>

        {/* Experience Timeline */}
        <div className="space-y-8">
          {experiences.map((exp, index) => (
            <Card 
              key={index}
              className="cyber-glow bg-card/30 backdrop-blur-sm border-border animate-fade-in"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <CardContent className="p-8">
                <div className="flex flex-col md:flex-row md:justify-between md:items-start mb-4">
                  <div>
                    <h3 className="text-2xl font-bold text-foreground mb-2">
                      {exp.title}
                    </h3>
                    <h4 className="text-xl text-primary mb-2">
                      {exp.company}
                    </h4>
                  </div>
                  <div className="flex flex-col md:items-end gap-2">
                    <Badge variant="outline" className="border-secondary text-secondary w-fit">
                      {exp.type}
                    </Badge>
                    <div className="flex items-center text-muted-foreground text-sm">
                      <Calendar size={16} className="mr-1" />
                      {exp.period}
                    </div>
                    {/* <div className="flex items-center text-muted-foreground text-sm">
                      <MapPin size={16} className="mr-1" />
                      {exp.location}
                    </div> */}
                  </div>
                </div>

                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {exp.description}
                </p>

                {/* Key Achievements */}
                <div className="mb-6">
                  <h5 className="text-lg font-semibold text-foreground mb-3">Key Achievements:</h5>
                  <ul className="space-y-2">
                    {exp.achievements.map((achievement, achievementIndex) => (
                      <li 
                        key={achievementIndex}
                        className="flex items-start text-muted-foreground"
                      >
                        <span className="text-accent mr-2 mt-1">▸</span>
                        {achievement}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Skills Used */}
                <div>
                  <h5 className="text-lg font-semibold text-foreground mb-3">Technologies & Skills:</h5>
                  <div className="flex flex-wrap gap-2">
                    {exp.skills.map((skill, skillIndex) => (
                      <Badge 
                        key={skillIndex}
                        variant="outline"
                        className="border-accent/50 text-accent hover:bg-accent/20"
                      >
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;